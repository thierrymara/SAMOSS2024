#' Total effects using winding stairs with correlation.
windsi <- function(d = NULL, Sigma=NULL, basic_size, model, trafo = id)
{
#      STI <- WINDSI(D,SIGMA,BASIC_SIZE,MODEL,TRAFO) computes these sensitivity
#       measures for MODEL taking input parameters with 
#       distribution TRAFO(NORMCDF(Normal(0,SIGMA))) for N base samples,
#       using (SIZE(SIGMA,1)-1)*N evaluations of MODEL
#
# Reference: I.M. Sobol', S. Tarantola, D. Gatelli, S.S. Kucherenko,
#            W. Mauntz: Estimating the approximation error when fixing 
#            unessential factors in global sensitivity analysis,
#            Reliab Eng Syst Safety 92 (2007), 957-960
#            A. Saltelli, P. Annoni, I. Azzini, F. Campolongo, M. Ratto, 
#            S. Tarantola: Variance based sensitivity analysis of model 
#			 output. Design and estimator for the total sensitivity index,
#            Comput. Phys. Comm. 181 (2010), 259-270
#            T. Goda, A simple algorithm for global sensitivity 
#                  analysis with Shapley effects, RESS 2021
#            E. Plischke, G. Rabitti, E. Borgonovo (2021)
#            E. Plischke: An effective algorithm (2010)
#            E. Borgonovo, E. Plischke, C. Prieur: Total Effects with Constrained Features, Stat. & Comput. (2024, forthcoming)

# written by elmar.plischke@tu-clausthal.de

# 
 if (is.null(d)) {
   if (is.null(Sigma))
    stop("Either d or Sigma needs to be specified")
   else {
    d <- nrow(Sigma)
# precompute the correlation weights
    D <-matrix(0,d,d);
    for (i in 1:d) {
      if(i == d) ii<- 1:d else ii <- c( (i+1):d,1:i)
      C <- chol(Sigma[ii,ii]);
      D[ii,i] <-  c( solve( C[1:(d-1),1:(d-1)], C[1:(d-1),d]), C[d,d])
    }  	
 } else {
  Sigma <- diag(d) 
  # C, D are also identities, then
  C <- diag(d)
  D <- diag(d)
 }
 # low discrepancy might be used here
 ua <- runif(basic_size*d); dim(ua) <- c(basic_size,d)
 zi <- rnorm(basic_size*d); dim(zi) <- c(basic_size,d) # innovation
 
# last C from the precomputation loop is in the correct order to provide
# Cholesky decomp for transformation

# correlated sample
za <- qnorm(ua)%*%C  # protect against norminv(normcdf)=inf via min(..,,8.20); 
# use the provided transformation or identity mapping
xa <- trafo(pnorm(za);
ya <- model(xa)
Vy <- var(ya)

Ti <- rep(1,d)
for (i in 1:d) {
# winding stairs: new basepoint
   yb <- ya;
# insert innovation at ith parameter
   za[,i] <- zi[,i]; 
 # correlate using the precomputed weights  
   za[,i] <- za %*% D[,i]
   xa <- trafo(pnorm(za));
   # evaluate model at alternative point
   ya <- model(xa); # evals <- evals+basic_size;
   dy <- ya-yb;
# for totals, use Jansen's formula
  Ti[i] <- sum(dy^2)/(2*basic_size*Vy);
# for an error estimate, check with Goda (without Var Y)
}
Ti
}

#' an identity function for use with default trafo 
id <- function(u) u

#' fills out random matrix
rand <- function(n, k) {u <- runif(n*k); dim(u) <- c(n,k); u}
# isScalar <- function (x) length(x) == 1L && is.vector(x, mode = "numeric")