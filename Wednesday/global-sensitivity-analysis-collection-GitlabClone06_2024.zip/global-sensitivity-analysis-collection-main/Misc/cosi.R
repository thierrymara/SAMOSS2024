#' Sensitivity Analysis in R -- Given Data Techniques
#' Version 2021-01-21

#' Compute variance-based first order effects via Cosine Transformation
#'
#' @param x An input matrix.
#' @param y A output vector.
#' @param M Maximum higher harmonics (defaults to 6).
#' @return The first order indices.
#' @examples
#'  n<-512;k<-3;
#'  x<-2*runif(n,k)-1;dim(x)=c(n,k); 
#'  y=sin(x[,1])*(1+0.1*x[,3]^4)+7*sin(x[,2])^2
#'  cosi(x,y)
#'  cosi(x,(y-mean(y)).^2)
#' @export
cosi <- function(x, y, M=6)
# first try of cosine sensitivity index (COSI) in R
# Ref.: E.Plischke, How to compute variance-based sensitivity indicators with
#       your spreadsheet software, EMS
# written by elmar.plischke@tu-clausthal.de
{
 nk <- dim(x); n <- nk[1]; k <- nk[2];
# discrete cosine transformation weight matrix
 W <- rep(0, times=n*M);
 dim(W) <- c(n,M);
 odds <- 2*(1:n)-1
 for (j in 1:M)
    W[ ,j] <- cos(pi*odds*j/(2*n));

 Si <- rep(0,times=k);
 for(j in 1:k)
 {
# cosine coefficients
  z <- sqrt(2/n)*y[order(x[ ,j])] %*% W;
# Parseval: work directly on coefficients
  Si[j]  <- sum(z * z);
 }
#return value 
 Si/var(y)/(n-1)
}
#' The Ishigami model
#' @export
ishigami.model <- function(x)  sin(x[,1])*(1+0.1*x[,3]^4)+7*sin(x[,2])^2
#' The input transformation for Ishigami model
#' @export
ishigami.trafo <- function(u)  pi*(2*u-1)
ishigami.factors <- 4; # including dummy

#' Fills out random matrix
#' @export
rand <- function(n, k) {u <- runif(n*k); dim(u) <- c(n,k); u}

#' Plots the cumulative sum of the normalized reordered output
#'
#' Also returns an estimate of the first order effects
#' Ref: E. Plischke, An adaptive correlation ratio method using the cumulative sum of the reordered output.
#' Reliability Engineering & System Safety 107, 149-156 (2012).  
#'
#' @param x An input matrix.
#' @param y A output vector.
#' @param M Number of interpolation points (defaults to 10).
#' @return The first order indices.
#' @export
cusunoro <- function(x, y, M=10)
{
# cumulative sum of normalized reordered output plot
# Ref.: E. Plischke, Adaptive Correlation Ratio Estimates 
#       using Cusunoro Curves, RESS 
 nk <- dim(x); n <- nk[1]; k <- nk[2];
 c <- (1:n)/n
 y <- (mean(y)-y)/(n*sqrt(var(y)));
 Si <- rep(0,k);

 z <- cumsum( y[order(x[ ,1])]) ;
 # mean squared gradient yields first order effect
 Ms <- seq(1, n, length.out=M); # for linear interpolation
 Si[1] <- sum(diff(z[Ms])^2)*M;
 plot(c, z, type="l", xlab="input quantiles", ylab="deviation from mean", ylim=c(-.3,.3))
 abline(h=0, lty=2);
 for(j in 2:k)
 {
  z <- cumsum( y[order(x[ ,j])]) ;
  Si[j] <- sum(diff(z[Ms])^2)*M;
  lines(c, z, col=j)
 }
 Si
}
#' Moment independent sensitivity methods using empirical cdfs.
#' Ref: Elmar Plischke, Emanuele Borgonovo,
#' Fighting the Curse of Sparsity: Probabilistic Sensitivity Measures 
#' From Cumulative Distribution Functions. Risk Analysis 40(12), 2639-2660 (2020).
#'
#' @param x An input matrix.
#' @param y A output vector.
#' @param M Partition size (defaults to 32).
#' @return A dataframe containing the following sensitivity indices:
#' KS  - Kolmogorov Smirnov 
#' Kui - Kuiper
#' Gin - Gini/Cram�r v. Mises
#' Gin2- Gini/Anderson Darling
#' CR  - Correlation Ratio/First Order Effects
#' @export 
betamim <- function(x, y, M=32)
{
  nk <- dim(x); n <- nk[1]; k <- nk[2];

  yindx  <- order(y);
  ydiffs <- as.vector(c(diff(y[yindx]), 0)); 
  cdf    <- (1:n)/n;
  m      <- seq(0, 1, length.out=M+1);
  bmi  <- rep(0,M); kmi <- rep(0,M); gmi <- rep(0,M); gmi2 <- rep(0,M); cmi <- rep(0,M);
  KS   <- rep(0,k); Kui <- rep(0,k); Gin <- rep(0,k); Gin2 <- rep(0,k); CR <- rep(0,k);
  # gfx: subplots
  par(mfrow=c(round(sqrt(k)), ceiling(sqrt(k))));
  for (i in 1:k) 
  { 
   xr <- rank(x[yindx,i])/n;
   for (j in 1:M)
   {
    indx <- (m[j]<xr) & (xr <= m[j+1]);
    ns   <- sum(indx); # subsample size
	cdfc <- cumsum(indx)/ns;
#	dcdf <- cdf[indx] - cdfc[indx];
    dcdf <- cdf - cdfc;
	mx   <- max(dcdf[indx]); mn <- min(dcdf[indx]);
	# graphics: conditional distributions 
	if (j==1)  
	{ 
	 plot(cdf, cdfc, type="S", col=j); 
	} else {
	 lines(cdf, cdfc, type="S", col=j); 
	}
	# should avoid empty indices ?
	bmi[j]  <- max(c(0, mx,-mn))*ns/n;
	kmi[j]  <- max(c(0, mx-mn))*ns/n;
	gmi[j]  <- drop(as.vector(dcdf^2) %*% ydiffs)*ns/n;
    gmi2[j] <- sum(dcdf^2)*ns/n^2;
	cmi[j]  <- drop(as.vector(dcdf) %*% ydiffs)^2*ns/n;
   }
   KS[i]   <- sum(bmi);
   Kui[i]  <- sum(kmi);
   Gin[i]  <- sum(gmi);
   Gin2[i] <- 6*sum(gmi2);
   CR[i]   <- sum(cmi)/var(y);
  }
  # return values (in a table)
  data.frame(KS, Kui, Gin, Gin2, CR)
}
#' Copula distance plot and derived sensitivity measures
#' Rank cusunoro curves are included for orientation
#'
#' Ref: Elmar Plischke, Emanuele Borgonovo,
#' Copula theory and probabilistic sensitivity analysis: Is there a connection?
#' European Journal of Operational Research 277(3), 1046-1059 (2019)
#'
#' @param x An input matrix.
#' @param y A output vector.
#' @return A dataframe containing the following sensitivity indices:
#' T    - Schweizer-Wolff weighted
#' Trho - Spearman Rho^2 weighted 
#' @export 
copdist <- function(x,y)
{
  nk <- dim(x); n <- nk[1]; k <- nk[2];
  T <- rep(0,k); 
  Trho <- rep(0,k); 
  ecdf <- (1:n)/n;
  yranks <- order(y);
  v <- ecdf[order(yranks)];

  M <- rep(0,times=n); # scaled rank cusunoro
  D <- rep(0,times=n); # copula distance
  InputCDF<-c(0,1);
  CopulaDifference<-c(-.25,.25);
  plot(InputCDF,CopulaDifference,type="n");

  for (j in 1:k)
  {
   xranks <- order(x[,j]);
   vr <- v[xranks];

   for (i in 1:n)
   {
    w<-vr[i];
    M[i] <- (i-2*sum(vr[1:i]))/(2*n)*sqrt(3);
    D[i] <- (sum(vr[1:i]<=w) - i*w)/n;
   }
   lines(ecdf,M,col=j); 
   points(ecdf,D,col=j,pch=j);
   #                         _
   # measures of the form _//  h(uv-C(uv)) dC(u,v)
   # are available by averaging over_h(D);
   # Instead of Schweizer/Wolff (_// |C -uv| dudv) 
   # I wanted to call them Italian Tigers
   # but this was rejected by my co-author :(
   Trho[j] <- 6*mean( D); # Spearman Rho^2 equivalent
   T[j] <- 6*mean( abs(D)); # S/W 
  }
 data.frame(Trho,T)
}
