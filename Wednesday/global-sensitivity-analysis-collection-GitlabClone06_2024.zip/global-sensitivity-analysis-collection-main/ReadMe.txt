This is a bunch of work-in-progress MatLab/Octave files for performing sensitivity analysis.

Codes assume that all subfolders are available in the path.

*********************************************
Elmar Plischke
Institut für Endlagerforschung
TU Clausthal

elmar.plischke@tu-clausthal.de

  