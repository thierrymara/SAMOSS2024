function y=dwtcdf97(x)
% discrete wavelet trafo fbi-wavelet
[n,k]=size(x);
if(n==2) 
  y=x; 
else
 if(k==1)
  d = x(2:2:n);
  s = x(1:2:n-1);
 else
  d = x(2:2:n,:);
  s = x(1:2:n-1,:);
 end
 d = d - 1.586134342*(s+ cpv(s,1));
 s = s - 0.05298011854*(cpv(d,-1)+ d);
 d = d + 0.8829110762*(s+ cpv(s,1));
 s = s + 0.4435068522*(cpv(d,-1)+ d); 
 d = d/1.149604398;
 s = s*1.149604398;

 y = [ dwtcdf97(s) ; d];
end
end
