%% A Smiley
%t=linspace(0,1);
n0=1000;n=5*n0;
t=rand(1,100);
x=2.25*cos(pi*t);y=2.25*sin(pi*t);
x=[x,2.25*cos(-pi*t)];y=[y,2.25*sin(-pi*t)];
x=[x,1.75*cos(-pi*t)];y=[y,1.75*sin(-pi*t)];
x=[x,1.1+.45*cos(2*pi*t)];
y=[y,.85+.45*sin(2*pi*t)];
x=[x,-1.1+.45*cos(2*pi*t)];
y=[y,.85+.45*sin(2*pi*t)];
%%
 linreg(x,y,'bla')